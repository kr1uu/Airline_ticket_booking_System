module.exports = {
  APP_NAME: process.env.REACT_APP_APP_NAME,
  NODE_ENV: process.env.REACT_APP_NODE_ENV,
  API_URL: process.env.REACT_APP_API_URL
};
